-- schema.sql (includes rol and usuario tables)
CREATE DATABASE IF NOT EXISTS agencia_medica;
USE agencia_medica;

CREATE TABLE IF NOT EXISTS rol (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE IF NOT EXISTS usuario (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  rol_id BIGINT,
  enabled BOOLEAN DEFAULT TRUE,
  FOREIGN KEY (rol_id) REFERENCES rol(id)
);

CREATE TABLE IF NOT EXISTS paciente (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  apellido VARCHAR(100) NOT NULL,
  cedula VARCHAR(30) NOT NULL UNIQUE,
  email VARCHAR(150),
  telefono VARCHAR(50),
  fecha_nacimiento DATE,
  direccion VARCHAR(255),
  created_at TIMESTAMP NULL,
  updated_at TIMESTAMP NULL
);

CREATE TABLE IF NOT EXISTS doctor (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  nombre VARCHAR(100) NOT NULL,
  apellido VARCHAR(100) NOT NULL,
  especialidad VARCHAR(100),
  licencia VARCHAR(50) UNIQUE,
  email VARCHAR(150),
  telefono VARCHAR(50),
  created_at TIMESTAMP NULL,
  updated_at TIMESTAMP NULL
);

CREATE TABLE IF NOT EXISTS cita_medica (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  paciente_id BIGINT NOT NULL,
  doctor_id BIGINT NOT NULL,
  fecha_hora DATETIME NOT NULL,
  motivo VARCHAR(255),
  estado VARCHAR(20) DEFAULT 'PROGRAMADA',
  observaciones TEXT,
  created_at TIMESTAMP NULL,
  updated_at TIMESTAMP NULL,
  FOREIGN KEY (paciente_id) REFERENCES paciente(id),
  FOREIGN KEY (doctor_id) REFERENCES doctor(id)
);

CREATE TABLE IF NOT EXISTS historial_clinico (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  paciente_id BIGINT NOT NULL,
  cita_id BIGINT,
  descripcion TEXT,
  diagnostico VARCHAR(255),
  tratamiento TEXT,
  fecha_registro DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (paciente_id) REFERENCES paciente(id),
  FOREIGN KEY (cita_id) REFERENCES cita_medica(id)
);

CREATE TABLE IF NOT EXISTS factura (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  paciente_id BIGINT NOT NULL,
  cita_id BIGINT,
  monto DECIMAL(10,2) NOT NULL,
  estado_pago VARCHAR(20) DEFAULT 'PENDIENTE',
  fecha_emision DATETIME DEFAULT CURRENT_TIMESTAMP,
  metodo_pago VARCHAR(50),
  detalle TEXT,
  FOREIGN KEY (paciente_id) REFERENCES paciente(id),
  FOREIGN KEY (cita_id) REFERENCES cita_medica(id)
);
