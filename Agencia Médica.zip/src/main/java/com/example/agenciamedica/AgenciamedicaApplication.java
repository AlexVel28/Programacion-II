package com.example.agenciamedica;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AgenciamedicaApplication {
    public static void main(String[] args) {
        SpringApplication.run(AgenciamedicaApplication.class, args);
    }
}
