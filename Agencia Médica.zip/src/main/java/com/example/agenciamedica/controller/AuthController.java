package com.example.agenciamedica.controller;

import com.example.agenciamedica.entity.Rol;
import com.example.agenciamedica.entity.Usuario;
import com.example.agenciamedica.repository.RolRepository;
import com.example.agenciamedica.repository.UsuarioRepository;
import com.example.agenciamedica.security.JwtUtil;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/v1/auth")
public class AuthController {

    private final UsuarioRepository usuarioRepository;
    private final RolRepository rolRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;

    public AuthController(UsuarioRepository usuarioRepository, RolRepository rolRepository, PasswordEncoder passwordEncoder, JwtUtil jwtUtil) {
        this.usuarioRepository = usuarioRepository;
        this.rolRepository = rolRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtUtil = jwtUtil;
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody Map<String, String> body) {
        String username = body.get("username");
        String password = body.get("password");
        String roleName = body.getOrDefault("role", "DOCTOR").toUpperCase();

        if (usuarioRepository.findByUsername(username).isPresent()) {
            return ResponseEntity.badRequest().body(Map.of("message", "Username ya existe"));
        }

        Rol rol = rolRepository.findByNombre(roleName).orElseGet(() -> {
            Rol r = new Rol();
            r.setNombre(roleName);
            return rolRepository.save(r);
        });

        Usuario u = new Usuario();
        u.setUsername(username);
        u.setPassword(passwordEncoder.encode(password));
        u.setRol(rol);
        u.setEnabled(true);
        usuarioRepository.save(u);

        return ResponseEntity.ok(Map.of("message", "Usuario creado"));
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> body) {
        String username = body.get("username");
        String password = body.get("password");

        return usuarioRepository.findByUsername(username).map(u -> {
            if (!passwordEncoder.matches(password, u.getPassword())) {
                return ResponseEntity.status(401).body(Map.of("message", "Credenciales inválidas"));
            }
            String token = jwtUtil.generateToken(u.getUsername());
            return ResponseEntity.ok(Map.of("token", token));
        }).orElseGet(() -> ResponseEntity.status(401).body(Map.of("message", "Credenciales inválidas")));
    }
}
