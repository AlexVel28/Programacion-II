Agencia Médica - Backend (Java Spring Boot) - Con JWT

Este proyecto incluye autenticación JWT y roles (ADMIN, DOCTOR).

Credenciales por defecto:

	- admin / admin123 (rol ADMIN)
	- doctor / doctor123 (rol DOCTOR)

	1. Ejecuta los scripts `sql/schema.sql` y `sql/data.sql` en MariaDB.
	2. Ajusta `src/main/resources/application.properties` con tus credenciales DB.
	3. Ejecuta `mvn spring-boot:run`
	4. Login: POST /api/v1/auth/login -> {"username":"admin","password":"admin123"}
   Copia el token y úsalo en `Authorization: Bearer <token>`


---- REQUISITOS PREVIOS A LA INSTALACIÓN ----

Antes de instalar y ejecutar el sistema, se debe de tener los siguientes componentes instalados para no tener ningún error:

	- JAVA JDK
	- MAVEN
	- POSTMAN
	- MARIA DB / MYSQL
	- IDE
	- NAVEGADOR WEB

---- DETALLE DE INSTALACIÓN DEL SISTEMA ----

	1. Descargar el archivo comprimido agencia_medica_jwt_project.zip.
	2. Descomprimir el archivo en una carpeta de tu preferencia.
	3. Abrir el proyecto en tu IDE (por ejemplo, IntelliJ IDEA o Eclipse).
	4. Esperar a que Maven descargue las dependencias del proyecto automáticamente.
	5. Revisar el archivo src/main/resources/application.properties y actualizar los valores de conexión según tu base de datos:

---- DETALLE DE CONFIGURACIÓN DE BASE DE DATOS ----

	1. Abrir HeidiSQL, MySQL Workbench o tu herramienta de administración de MariaDB.
	2. Ejecutar los siguientes scripts en orden:
	   - sql/schema.sql → crea las tablas de la base de datos.
	   - sql/data.sql → inserta datos de ejemplo y usuarios por defecto.
	3. Verifica que se haya creado la base de datos agencia_medica con sus tablas (paciente, doctor, cita_medica, historial_clinico, factura, usuario, rol).

---- DETALLE DE EJECUCIÓN DEL SISTEMA ----

	1. En IDE ejecutar clase principal "AgenciamedicaApplication.java"
	2. Esperar el mensaje "Started AgenciamedicaApplication in X seconds"
	3. El server se ejecutará por defecto en "http://localhost:8080"