-- data.sql (roles, users and sample data)
USE agencia_medica;

INSERT INTO rol (nombre) VALUES ('ADMIN') ON DUPLICATE KEY UPDATE nombre=nombre;
INSERT INTO rol (nombre) VALUES ('DOCTOR') ON DUPLICATE KEY UPDATE nombre=nombre;

-- Replace the password hashes with those generated in your environment if you prefer.
INSERT INTO usuario (username, password, rol_id, enabled)
VALUES
('admin', '$2a$10$yWq0q9fSHTYcF2HnZx7W6uW9k0lDqj4w2u4b8b6q9sQKf1bVZr9eG', (SELECT id FROM rol WHERE nombre='ADMIN'), true)
ON DUPLICATE KEY UPDATE username=username;

INSERT INTO usuario (username, password, rol_id, enabled)
VALUES
('doctor', '$2a$10$Jp6Zc0Gk5yQKqg8h7T9E3u1s2tVb5cYwX9ZpL6a7b8C9d0E1F2GHi', (SELECT id FROM rol WHERE nombre='DOCTOR'), true)
ON DUPLICATE KEY UPDATE username=username;

-- sample patients, doctors, citas, etc.
INSERT INTO paciente (nombre, apellido, cedula, email, telefono, fecha_nacimiento, direccion)
VALUES
('Juan', 'Perez', '12345678', 'juan.perez@example.com', '5554-1234', '1990-05-10', 'Ciudad'),
('Maria', 'Lopez', '87654321', 'maria.lopez@example.com', '5554-5678', '1985-11-20', 'Ciudad');

INSERT INTO doctor (nombre, apellido, especialidad, licencia, email, telefono)
VALUES
('Carlos', 'Mendez', 'Medico General', 'LIC-001', 'c.mendez@clinica.com', '5550-1111'),
('Ana', 'Ruiz', 'Pediatra', 'LIC-002', 'a.ruiz@clinica.com', '5550-2222');

INSERT INTO cita_medica (paciente_id, doctor_id, fecha_hora, motivo, estado)
VALUES
(1, 1, '2025-10-15 09:30:00', 'Consulta general', 'REALIZADA'),
(1, 2, '2025-11-01 14:00:00', 'Control pediatrico', 'PROGRAMADA'),
(2, 1, '2025-10-20 11:00:00', 'Dolor de cabeza', 'REALIZADA');

INSERT INTO historial_clinico (paciente_id, cita_id, descripcion, diagnostico, tratamiento)
VALUES
(1, 1, 'Paciente con sintomas leves', 'Gripe', 'Reposo y analgesicos'),
(2, 3, 'Dolor persistente', 'Migraña', 'Tratamiento con medicacion X');

INSERT INTO factura (paciente_id, cita_id, monto, estado_pago, metodo_pago, detalle)
VALUES
(1, 1, 150.00, 'PAGADO', 'Tarjeta', 'Consulta general'),
(2, 3, 200.00, 'PENDIENTE', 'Efectivo', 'Consulta especial');
